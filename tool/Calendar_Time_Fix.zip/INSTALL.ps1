param([string]$ProjectRoot = 'D:\bangla_panjika_native')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$target = Join-Path $ProjectRoot 'lib\main.dart'
$payload = Join-Path $PSScriptRoot 'payload\main.dart'
$originalHash = '8604BA13057255EB3E41A46C4B21012BCE06C97375D0170FC10161F508403443'
$patchedHash = '3C481ED6C559288444AE2B2868001007A94533AF115A3B90F06D47B33BC73C9E'
$backupFile = $null
$installed = $false
try {
    if (!(Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Project main.dart not found.' }
    if (!(Test-Path -LiteralPath $payload -PathType Leaf)) { throw 'Extract the complete ZIP before running INSTALL.ps1.' }
    if ((Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash -ne $patchedHash) { throw 'Package verification failed. Nothing changed.' }
    $currentHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($currentHash -eq $patchedHash) {
        Write-Host 'This fix is already installed.' -ForegroundColor Green
        exit 0
    }
    if ($currentHash -ne $originalHash) { throw 'Your main.dart has changed since the uploaded ZIP. Stopped without replacing it.' }
    $null = Get-Command flutter -ErrorAction Stop
    $dartCommand = Get-Command dart -ErrorAction Stop
    & $dartCommand.Source format --output=none $payload
    if ($LASTEXITCODE -ne 0) { throw 'Dart syntax check failed. Nothing changed.' }
    # Perform the calculation check on the target PC before touching app source.
    & $dartCommand.Source (Join-Path $PSScriptRoot 'checks\check_panchang_clock.dart') $payload
    if ($LASTEXITCODE -ne 0) { throw 'Calculation checks failed. Nothing changed.' }
    $backupDir = Join-Path (Split-Path $ProjectRoot -Parent) ('CalendarBackup_' + [guid]::NewGuid().ToString('N'))
    $null = New-Item -ItemType Directory -Path $backupDir
    $backupFile = Join-Path $backupDir 'main.dart'
    Copy-Item -LiteralPath $target -Destination $backupFile
    if ((Get-FileHash -LiteralPath $backupFile -Algorithm SHA256).Hash -ne $originalHash) { throw 'Backup verification failed. Nothing changed.' }
    # Do not overwrite any edit made while the checks were running.
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $originalHash) { throw 'Source changed during checks. Stopped.' }
    Write-Host "Verified backup: $backupFile" -ForegroundColor Cyan
    $installed = $true
    Copy-Item -LiteralPath $payload -Destination $target -Force
    if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $patchedHash) { throw 'Installed file verification failed.' }
    Push-Location $ProjectRoot
    try {
        # Reuse existing dependency resolution; do not rewrite pubspec/lockfiles.
        flutter build apk --debug --no-pub -t lib/main.dart
        if ($LASTEXITCODE -ne 0) { throw 'Android debug build failed.' }
    } finally { Pop-Location }
    Write-Host 'Fix installed and Android debug build passed.' -ForegroundColor Green
    Write-Host "Backup kept at: $backupFile"
} catch {
    $problem = $_.Exception.Message
    if ($installed -and $backupFile -and (Test-Path -LiteralPath $backupFile)) {
        Copy-Item -LiteralPath $backupFile -Destination $target -Force
        if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $originalHash) {
            Write-Host "Restore verification failed. Backup: $backupFile" -ForegroundColor Red
            exit 2
        }
        Write-Host 'Original main.dart restored. Fix was not kept.' -ForegroundColor Yellow
    }
    Write-Host $problem -ForegroundColor Red
    exit 1
}
