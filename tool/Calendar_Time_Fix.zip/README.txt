Calendar time repair — based only on CalendarSource_20261013_140754.zip

This package is a separate patch; the original uploaded ZIP remains intact.
Only lib/main.dart is installed. No dependency, Android signing, ads, backend,
UI layout, asset, festival table, holiday file or Bengali month rule is replaced.

Changes:
- Preserve the IST marker in tithi transition bisection.
- Correct actual-instant conversion for countdowns/reminders outside IST.
- Replace all 7 moonrise approximations with a shared lunar horizon-crossing
  calculation using the existing celestial position model. Moonset is computed
  separately. Date/location cache is bounded; no-event days display text.
- Use daylight/15 for Abhijit consistently in both calculation paths.
- Use the existing IST convention for both nighttime festival references.

Verification performed here:
- Dart parser accepted the full updated main.dart.
- Arithmetic consistency checks passed for 38 dates (2025–2027), 2 locations,
  and 4 Linux timezones, including local/IST equivalence and lunar crossings.
- Current holiday data checks passed.
- Diff reviewed; all other uploaded files remain byte-identical.
- No full Flutter build or physical-device test was possible here.

INSTALL.ps1 checks payload and current-source SHA256, checks Dart syntax and
calculation consistency on your PC, makes a verified backup outside lib, then
builds the Android debug APK. On build failure it restores original main.dart.
On Windows the calculation checker tests the device timezone only, since TZ
process overrides are not portable there. The four timezone runs were on Linux.
Keep the app/debug session stopped while installing. If the source changed
since the uploaded ZIP, installation stops without overwriting it.
A successful debug build is not a guarantee of every UI/runtime behavior.

Not resolved by this patch:
- The truncated astronomy model still has residual accuracy differences; this
  package does not claim ephemeris-grade precision.
- The existing Bhadra/Ashwin extra-day rule is unchanged. A calendar-reference
  decision and additional date fixtures are required before changing it.
- GPS vs manually chosen district consistency and real notification delivery
  need further review/device testing.

After the installer succeeds, use flutter run -t lib/main.dart to test.
No production release, Play Store upload, app-data deletion or git reset occurs.
